# Missing comparison-row classification

Source: `audit/visuals/compare/index.json` at start of this bookkeeping pass  
(`compared=57`, `missing=39`, `PAIRS×VIEWPORTS=96`).

Aborted capture/render shell jobs are **not** counted as completed coverage.

## Counts

| Unit | Count |
| --- | --- |
| Missing comparison rows (slug×viewport) | **39** |
| Unique screens/slugs with ≥1 missing row | **22** |
| Of those unique: Flutter capture missing only | **3** (`menu-ready`, `merchant-info-ready`, `restore-loading-ready` — 17 Pro) |
| Of those unique: Stitch missing (Flutter present) | **18** |
| Of those unique: both missing | **1** (`merchant-reviews-ready` 17 Pro) |
| Unsupported capability (not in the 39) | splash/payment artboards were **outside** `PAIRS`; delivery-code / receipt / live Chargily remain unsupported |
| Duplicate / incorrect mapping | `annuler_la_commande_speedygo` → both `orders-cancelled-ready` and `order-cancel-form-ready` (intentional alias; cancel **form** is the correct remaining compare). `menu_speedygo` ≈ storefront menu chrome (same Flutter screen as merchant detail). |

## Per missing row

| Slug | Viewport | Classification | Notes |
| --- | --- | --- | --- |
| `account-delete-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | Flutter present; HTML `suppression_du_compte_speedygo` |
| `account-language-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | |
| `checkout-method-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | |
| `checkout-notes-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | Honest placeholder vs Stitch write UI |
| `favorites-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | Honest placeholder |
| `legal-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | |
| `location-permission-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | |
| `logout-sheet-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | |
| `menu-ready` | 17 Pro only | Implemented, **Flutter capture missing** | SE Flutter + both Stitch present |
| `merchant-info-ready` | 17 Pro only | Implemented, **Flutter capture missing** | |
| `merchant-reviews-ready` | 17 Pro | Implemented, **Flutter + Stitch missing** | SE Flutter present; SE Stitch present |
| `notification-prefs-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | |
| `order-rate-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | |
| `order-write-review-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | |
| `promotions-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | |
| `restore-loading-ready` | 17 Pro only | Implemented, **Flutter capture missing** | SE Flutter + both Stitch present |
| `support-create-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | |
| `tracking-completed-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | Mocked tracking |
| `tracking-map-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | |
| `tracking-nearby-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | |
| `tracking-searching-ready` | SE, 17 Pro | Implemented, **Stitch render missing/timeout** | |
| `tracking-waiting-ready` | 17 Pro only | Implemented, **Stitch render missing/timeout** | SE compared already |

## Outside the 39 (bookkeeping)

| Item | Classification |
| --- | --- |
| `splash_speedygo` / `splash_speedygo2` | Implemented; Flutter frames + Stitch not previously in `PAIRS` |
| `paiement_speedygo` / `redirection_vers_le_paiement_speedygo` | Implemented UI + **production gate off**; live PSP **unsupported** |
| Delivery code / receipt / delivery-notes preview | **Unsupported capability** |
| `payment-methods-ready` Flutter captures | Honest empty cards; no dedicated Stitch pair in `PAIRS` |

Update this file after bounded re-render + focused Flutter capture; final row statuses live in `audit/visuals/compare/index.json` and the review zip index.
