# Customer visual review package

**Comparison generated ≠ visual match accepted.** Every row below is for human review.

Compare index at pack time: compared=105 missing=9 (slug×viewport).
Unique screens with a compared pair: 57.

Labels on side-by-sides: left = Stitch/reference, right = Flutter (mocked) unless noted live.

## Index (SE primary)

| Screen/state | Viewport | Artifact | Visual conclusion (pending human) | Notes |
| --- | --- | --- | --- | --- |
| `home-ready` | se-375x667 | `side-by-side/home-ready__se-375x667.jpg` | **layout_ok_pending_review** | 5 FR tabs vs Stitch 4 EN; Commerces vs nearby claim; no invented ETA. |
| `categories-ready` | se-375x667 | `side-by-side/categories-ready__se-375x667.jpg` | **layout_ok_pending_review** | Search + explorer cards; 5-tab shell. |
| `category-results-ready` | se-375x667 | `side-by-side/category-results-ready__se-375x667.jpg` | **contract_diff** | Live names/hours; no Stitch ETA/Populaire. |
| `storefront-ready` | se-375x667 | `side-by-side/storefront-ready__se-375x667.jpg` | **layout_ok_pending_review** | Cover may be placeholder in mocks. |
| `product-ready` | se-375x667 | `side-by-side/product-ready__se-375x667.jpg` | **layout_ok_pending_review** | Sticky CTA; SE overflow previously fixed. |
| `product-options-ready` | se-375x667 | `side-by-side/product-options-ready__se-375x667.jpg` | **layout_ok_pending_review** | Options configure chrome. |
| `search-idle` | se-375x667 | `side-by-side/search-idle__se-375x667.jpg` | **contract_diff** | No fabricated recents. |
| `search-results-ready` | se-375x667 | `side-by-side/search-results-ready__se-375x667.jpg` | **layout_ok_pending_review** | Results AppBar field when showBack. |
| `cart-ready` | se-375x667 | `side-by-side/cart-ready__se-375x667.jpg` | **contract_diff** | Title Panier vs Stitch Merchant Details. |
| `checkout-address-ready` | se-375x667 | `side-by-side/checkout-address-ready__se-375x667.jpg` | **layout_ok_pending_review** | Address picker. |
| `checkout-review-ready` | se-375x667 | `side-by-side/checkout-review-ready__se-375x667.jpg` | **contract_diff** | HTML reorder board ≠ live review. |
| `orders-in-progress-ready` | se-375x667 | `side-by-side/orders-in-progress-ready__se-375x667.jpg` | **layout_ok_pending_review** | List + filters. |
| `order-detail-ready` | se-375x667 | `side-by-side/order-detail-ready__se-375x667.jpg` | **layout_ok_pending_review** | Detail financials. |
| `orders-cancelled-ready` | se-375x667 | `side-by-side/orders-cancelled-ready__se-375x667.jpg` | **duplicate_mapping** | Stitch cancel artboard also aliases cancel form. |
| `account-hub-ready` | se-375x667 | `side-by-side/account-hub-ready__se-375x667.jpg` | **layout_ok_pending_review** | 5 FR tabs. |
| `addresses-ready` | se-375x667 | `side-by-side/addresses-ready__se-375x667.jpg` | **layout_ok_pending_review** | Saved addresses. |
| `support-detail-ready` | se-375x667 | `side-by-side/support-detail-ready__se-375x667.jpg` | **layout_ok_pending_review** | Ticket thread. |
| `notifications-ready` | se-375x667 | `side-by-side/notifications-ready__se-375x667.jpg` | **layout_ok_pending_review** | Inbox. |
| `sessions-ready` | se-375x667 | `side-by-side/sessions-ready__se-375x667.jpg` | **layout_ok_pending_review** | Security sessions. |
| `language-ready` | se-375x667 | `side-by-side/language-ready__se-375x667.jpg` | **contract_diff** | FR only; AR disabled. |
| `welcome-ready` | se-375x667 | `side-by-side/welcome-ready__se-375x667.jpg` | **layout_ok_pending_review** | Hero aspect may differ from square Stitch. |
| `phone-ready` | se-375x667 | `side-by-side/phone-ready__se-375x667.jpg` | **layout_ok_pending_review** | Phone entry. |
| `otp-ready` | se-375x667 | `side-by-side/otp-ready__se-375x667.jpg` | **layout_ok_pending_review** | OTP entry. |
| `profile-setup-ready` | se-375x667 | `side-by-side/profile-setup-ready__se-375x667.jpg` | **layout_ok_pending_review** | Profile setup. |
| `restore-loading-ready` | se-375x667 | `side-by-side/restore-loading-ready__se-375x667.jpg` | **layout_ok_pending_review** | Session restore chrome. |
| `checkout-method-ready` | se-375x667 | `side-by-side/checkout-method-ready__se-375x667.jpg` | **contract_diff** | ELECTRONIC gated; no Stitch sticky total bar. |
| `order-confirmation-ready` | se-375x667 | `side-by-side/order-confirmation-ready__se-375x667.jpg` | **layout_ok_pending_review** | Commande envoyée; 140px bottom padding; row ellipsis fix this pass. |
| `menu-ready` | se-375x667 | `side-by-side/menu-ready__se-375x667.jpg` | **duplicate_mapping** | Same Flutter storefront/menu chrome as merchant detail. |
| `merchant-info-ready` | se-375x667 | `side-by-side/merchant-info-ready__se-375x667.jpg` | **layout_ok_pending_review** | Hours from fixture. |
| `merchant-reviews-ready` | se-375x667 | `side-by-side/merchant-reviews-ready__se-375x667.jpg` | **contract_diff** | Summary only; no public comments. |
| `order-cancel-form-ready` | se-375x667 | `side-by-side/order-cancel-form-ready__se-375x667.jpg` | **layout_ok_pending_review** | 140px bottom padding clears sticky footer. |
| `tracking-waiting-ready` | se-375x667 | `side-by-side/tracking-waiting-ready__se-375x667.jpg` | **mocked_only** | Not live delivery proof. |
| `tracking-searching-ready` | se-375x667 | `side-by-side/tracking-searching-ready__se-375x667.jpg` | **mocked_only** | Not live delivery proof. |
| `tracking-map-ready` | se-375x667 | `side-by-side/tracking-map-ready__se-375x667.jpg` | **mocked_only** | Coords only; no map SDK. |
| `tracking-nearby-ready` | se-375x667 | `side-by-side/tracking-nearby-ready__se-375x667.jpg` | **mocked_only** | Not live delivery proof. |
| `tracking-completed-ready` | se-375x667 | `side-by-side/tracking-completed-ready__se-375x667.jpg` | **mocked_only** | Not live delivery proof. |
| `order-rate-ready` | se-375x667 | `side-by-side/order-rate-ready__se-375x667.jpg` | **mocked_only** | COMPLETED fixture. |
| `order-write-review-ready` | se-375x667 | `side-by-side/order-write-review-ready__se-375x667.jpg` | **layout_ok_pending_review** | CTA Envoyer l’avis. |
| `account-language-ready` | se-375x667 | `side-by-side/account-language-ready__se-375x667.jpg` | **layout_ok_pending_review** | Language prefs. |
| `support-create-ready` | se-375x667 | `side-by-side/support-create-ready__se-375x667.jpg` | **layout_ok_pending_review** | Submit pinned above keyboard. |
| `legal-ready` | se-375x667 | `side-by-side/legal-ready__se-375x667.jpg` | **unsupported** | Honest empty; no CMS. |
| `notification-prefs-ready` | se-375x667 | `side-by-side/notification-prefs-ready__se-375x667.jpg` | **unsupported** | No prefs API. |
| `account-delete-ready` | se-375x667 | `side-by-side/account-delete-ready__se-375x667.jpg` | **contract_diff** | No password field vs Stitch. |
| `favorites-ready` | se-375x667 | `side-by-side/favorites-ready__se-375x667.jpg` | **unsupported** | Honest placeholder. |
| `promotions-ready` | se-375x667 | `side-by-side/promotions-ready__se-375x667.jpg` | **contract_diff** | List placeholder; Home banner is live path. |
| `checkout-notes-ready` | se-375x667 | `side-by-side/checkout-notes-ready__se-375x667.jpg` | **unsupported** | No write field. |
| `location-permission-ready` | se-375x667 | `side-by-side/location-permission-ready__se-375x667.jpg` | **layout_ok_pending_review** | Permission chrome. |
| `logout-sheet-ready` | se-375x667 | `side-by-side/logout-sheet-ready__se-375x667.jpg` | **layout_ok_pending_review** | Modal from Profil. |
| `splash-frame-front` | se-375x667 | `side-by-side/splash-frame-front__se-375x667.jpg` | **layout_ok_pending_review** | Animation frame; behavior unchanged. |
| `splash-frame-edge` | se-375x667 | `side-by-side/splash-frame-edge__se-375x667.jpg` | **layout_ok_pending_review** | Flip edge frame. |
| `splash-frame-back` | se-375x667 | `side-by-side/splash-frame-back__se-375x667.jpg` | **layout_ok_pending_review** | Blank back face; no mirrored lettering. |
| `splash-frame-static` | se-375x667 | `side-by-side/splash-frame-static__se-375x667.jpg` | **layout_ok_pending_review** | Reduced-motion / static. |
| `payment-disabled-ready` | se-375x667 | `side-by-side/payment-disabled-ready__se-375x667.jpg` | **mocked_only** | Gate off; not provider evidence. |
| `payment-pending-ready` | se-375x667 | `side-by-side/payment-pending-ready__se-375x667.jpg` | **mocked_only** | Isolated mock PROCESSING. |
| `payment-failed-ready` | se-375x667 | `side-by-side/payment-failed-ready__se-375x667.jpg` | **mocked_only** | Isolated mock FAILED. |
| `payment-succeeded-ready` | se-375x667 | `side-by-side/payment-succeeded-ready__se-375x667.jpg` | **mocked_only** | Isolated mock SUCCEEDED. |
| `payment-redirect-ready` | se-375x667 | `side-by-side/payment-redirect-ready__se-375x667.jpg` | **mocked_only** | Redirect title chrome; gate off. |
| `home-ready` | iphone17pro-402x874 | `side-by-side/home-ready__iphone17pro-402x874.jpg` | **layout_ok_pending_review** | 5 FR tabs vs Stitch 4 EN; Commerces vs nearby claim; no invented ETA. |
| `order-confirmation-ready` | iphone17pro-402x874 | `side-by-side/order-confirmation-ready__iphone17pro-402x874.jpg` | **layout_ok_pending_review** | Commande envoyée; 140px bottom padding; row ellipsis fix this pass. |
| `menu-ready` | iphone17pro-402x874 | `side-by-side/menu-ready__iphone17pro-402x874.jpg` | **duplicate_mapping** | Same Flutter storefront/menu chrome as merchant detail. |

## Live photographed product (gesture proof)

| Shot | Path | Conclusion |
| --- | --- | --- |
| Menu thumbnail | `live-photo/live-photo-menu.jpg` | **live_pass** — Croissant au beurre `authenticated-catalog-image` |
| Product detail | `live-photo/live-photo-product.jpg` | **live_pass** — bound photo loaded |
| Pain khobz | (not shot as photo proof) | **content_gap** — no `product_images`; placeholder correct |

## Before/after (visible fixes)

| Item | Path | Conclusion |
| --- | --- | --- |
| Padding note | `before-after/padding-fix-note.jpg` | Pre-fix golden not archived |
| Confirmation after | `before-after/order-confirmation-after-padding-se-375x667.jpg` | **layout_verified** — CTAs reachable; 140px kept |
| Cancel after | `before-after/order-cancel-after-padding-se-375x667.jpg` | **layout_verified** |
| Confirmation text 1.3 | `before-after/order-confirmation-after-padding-se-375x667-text-1.3.jpg` | **layout_verified** |
| Cancel text 1.3 | `before-after/order-cancel-after-padding-se-375x667-text-1.3.jpg` | **layout_verified** |
| Support keyboard | `before-after/support-create-keyboard-se-375x667.jpg` | **layout_verified** |

## Remaining missing comparison rows (9)

All are **Flutter capture missing on 17 Pro only** for splash frames + payment mocks (SE captured). Stitch present.

| Slug | Viewport | Classification |
| --- | --- | --- |
| `splash-frame-front` | iphone17pro-402x874 | Implemented; Flutter 17 Pro capture not taken this pass |
| `splash-frame-edge` | iphone17pro-402x874 | Implemented; Flutter 17 Pro capture not taken this pass |
| `splash-frame-back` | iphone17pro-402x874 | Implemented; Flutter 17 Pro capture not taken this pass |
| `splash-frame-static` | iphone17pro-402x874 | Implemented; Flutter 17 Pro capture not taken this pass |
| `payment-disabled-ready` | iphone17pro-402x874 | Implemented; Flutter 17 Pro capture not taken this pass |
| `payment-pending-ready` | iphone17pro-402x874 | Implemented; Flutter 17 Pro capture not taken this pass |
| `payment-failed-ready` | iphone17pro-402x874 | Implemented; Flutter 17 Pro capture not taken this pass |
| `payment-succeeded-ready` | iphone17pro-402x874 | Implemented; Flutter 17 Pro capture not taken this pass |
| `payment-redirect-ready` | iphone17pro-402x874 | Implemented; Flutter 17 Pro capture not taken this pass |

## Unsupported capabilities (do not treat as incomplete implemented UI)

- Delivery code API / receipt / delivery-notes preview-only
- Live Chargily electronic payment (production gate off; mocks ≠ provider proof)
- Map SDK live tracking

## Source docs

- `missing-comparison-classification.md` (full 39-row closeout)
- `05-visual-verification.md`
- `02-screen-matrix.md`

Aborted capture jobs are **not** counted as coverage.
